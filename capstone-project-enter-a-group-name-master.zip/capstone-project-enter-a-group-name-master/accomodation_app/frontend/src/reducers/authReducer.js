import {
  LOGIN,
  LOGOUT,
  REGISTER_USER,
  LOGIN_USER,
  ERROR_MSG,
  REDIRECT_AFTER_LOGIN
} from '../actions/types';


const initialState = {
  loggedIn: false,
  user: null,
  token: '',
  errorEmail: '',
  errorUsername: '',
  redirect: false,
};

export default (auth = initialState, action) => {
  let newState = { ...auth };
  switch (action.type) {

    case LOGOUT:
      newState.loggedIn = false;
      newState.token = '';
      newState.user = null;
      newState.redirect = false;
      return newState;

    case REGISTER_USER:
      newState.errorEmail = '';
      newState.errorUsername = '';
      return newState;

    case LOGIN_USER:
      newState.loggedIn = true
      newState.user = action.payload.user
      newState.token = action.payload.token
      console.log(newState)
      return newState;

    case ERROR_MSG:

      console.log(action.payload)

      newState.errorMessage = []

      if (action.payload.data.email) {
        console.log("email problem exists: ")
        newState.errorEmail = action.payload.data.email[0];
      }
      if (action.payload.data.username) {
        console.log("username problem exists: ")
        newState.errorUsername = action.payload.data.username[0];
      }

      console.log(newState.errorMessage)
      return newState;

    case REDIRECT_AFTER_LOGIN:
      console.log('Redirection after login reacts')
      newState.redirect = action.payload;
      return newState;

    default:
      return auth;
  }
}