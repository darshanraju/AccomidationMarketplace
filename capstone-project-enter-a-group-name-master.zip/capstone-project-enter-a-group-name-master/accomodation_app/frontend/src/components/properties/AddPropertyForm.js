import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import { Field, reduxForm } from 'redux-form';
import { compose } from 'redux';
//import Dropzone from 'react-dropzone-uploader';
import ImageUploader from 'react-images-upload';
import { withStyles } from '@material-ui/core/styles';

import FieldFileInput, { renderTextField } from '../../utils/renderFormComponents';

const styles = (theme) => ({
  content: {
    flexGrow: 1,
    marginTop: '20px',
    display: 'flex',
    alignItems: 'center',
    flexDirection: 'column',
  }
})

class AddPropertyForm extends Component {
  state = {
    pictures: []
  };

  onDrop = (picture) => {
    this.setState({ pictures: picture });
  }

  render() {
    const { classes } = this.props;

    return (
      <React.Fragment>
        <div className={classes.content}>
          <form onSubmit={this.props.handleSubmit}>
            <div><Field name="address" component={renderTextField} label="Address" /></div>
            <div><Field name="suburb" component={renderTextField} label="Suburb" /></div>
            <div><Field name="postcode" component={renderTextField} label="Postcode" /></div>
            <div><Field name="price" component={renderTextField} label="Price" /></div>
            <div><Field name="no_guests" component={renderTextField} label="Number of Guests" /></div>
            <div><Field name="no_beds" component={renderTextField} label="Number of Beds" /></div>
            <div><Field name="no_bathrooms" component={renderTextField} label="Number of Bathrooms" /></div>
            <div><Field name="images" component={FieldFileInput} /></div>
            <Button type="submit">Submit</Button>
          </form>
        </div>
      </React.Fragment>
    )
  }
}

export default compose(
  reduxForm({ form: 'addProperty' }),
  withStyles(styles)
)(AddPropertyForm);