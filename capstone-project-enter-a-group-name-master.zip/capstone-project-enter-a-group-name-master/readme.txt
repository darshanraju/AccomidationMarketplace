How to build, setup and Configure the project  
First time setup: 
Step 1 -  Download the project repository.
 
Step 2 -  install pipenv with python 3.7 (skip this step if already installed, note: pipenv is not on the cse machines by default) type:
pip install pipenv	

Step 3 -  create/start a virtual environment for the project. type:
pipenv shell

Step 4 - install all python dependencies. type:
 pipenv sync

Step 5 - install NVM. type:
	curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.33.8/install.sh | bash

Step 6 - Download Node v12.10.0 using NVM. type:
	nvm install 12.10.0
nvm use 12.10.0

Step 7 - install all javascript dependencies. Type:
	npm install

Step 8 -  compile the javascript. Type:
	npm run build

Step 9 -  change into the accommodation_app directory.  Type:
	cd accomodation_app

Step 10 - run makemigrations and migrations. Type: 
python manage.py makemigrations
python manage.py migrate 

Step 11 - Serve django web application. Type:
python manage.py runserver
Step 12 - open the Web Application. Open a browser and type http://localhost:8000/ into the url. [ IMPORTANT: Do not use the localhost ip 127.0.0.1:8000 to run the app. Images may not display properly ]
Restarting the project 
Step 1 - change into the projects directory (.../capstone-project-enter-a-group-name). 

Step 2 - start a virtual environment for the project. type:
pipenv shell

Step 3 -  change into the accommodation_app directory.  Type:
	cd accomodation_app

Step 4 - Serve django web application. Type:
python manage.py runserver
Step 5 - open the Web Application. Open a browser and type http://localhost:8000/ into the url. 
How to load test data for the project 
When downloaded the database will contain no properties to test with. Follow the steps below If you would like to add some test properties to the database inorder to test the functionality.  There are 51 reall addresses sourced from google maps and the following website <https://www.google.com.au/travel/hotels/New%20South%20Wales?g2lb=2502405%2C2502548%2C4208993%2C4254308%2C4258168%2C4260007%2C4270442%2C4274032%2C4285990%2C4288513%2C4289525%2C4291318%2C4296668%2C4301054%2C4305595%2C4308216%2C4311410%2C4313006%2C4315873%2C4317816%2C4317915%2C4318271%2C4319579%2C4324289%2C4329496%2C4270859%2C4284970%2C4291517%2C4292955%2C4316256&hl=en&gl=au&un=1&ap=SAEqKAoSCdx2xgH9aEHAEUh-j4MvtmFAEhIJakBfjU1LOMARSH6Pgz-lYkAwAlqNAQoFCKwCEAAiA0FVRCoWCgcI4w8QDBgBEgcI4w8QDBgCGAEoALABAFgBaAGKASgKEgn5GHoNw9RBwBHwnMorh6NhQBISCfWAFtDzOjnAEfCcyiuXkmJAmgEREg9OZXcgU291dGggV2FsZXOiARsKCC9tLzA1Zmx5Eg9OZXcgU291dGggV2FsZXOSAQIgAQ&q=hotels%20motels%20nsw&rp=EMSIt6rMru2FBBCWw-qr1NjplYwBEKvJq4_ZgqewExDqp5n9sb2aoZUBaAE4AUAASAI&ictx=1&ved=2ahUKEwjA1NKlruHlAhXRXisKHfA2BwMQtgN6BAgKEE0&hrf=CgUIrAIQACIDQVVEKhYKBwjjDxAMGAESBwjjDxAMGAIYASgAsAEAWAFoAYoBKAoSCdx2xgH9aEHAEUh-j4MvtmFAEhIJakBfjU1LOMARSH6Pgz-lYkCaARESD05ldyBTb3V0aCBXYWxlc6IBGwoIL20vMDVmbHkSD05ldyBTb3V0aCBXYWxlc5IBAiAB&tcfs=EjUKCC9tLzA1Zmx5Eg9OZXcgU291dGggV2FsZXMaGAoKMjAxOS0xMi0wMRIKMjAxOS0xMi0wMiIYCgoyMDE5LTEyLTAxEgoyMDE5LTEyLTAyUgA, >. We generate 10 more properties form each of these properties. Please note running this again will generate repeated property entries. 

Step 1: go to the project directory and change into the accommodation_app directory. From .../capstone-project-enter-a-group-name/    Type:
	cd accomodation_app

Step 2:  if you have not already made a user then, run the application and register a user, else skip this step. The first user you create will own all the properties created by this generator. 

Step 3: run the django shell. Type:
	python manage.py shell
Note the django shell will be opened up. 

Step 4: import the algorithm in the shell. From inside the django shell window type:
	from property.tests import GenerateTestPropertys

Step 5: run the generator: From inside the django shell window type:
Note: Users must be generated first. Do not add other users through the web app before doing this to ensure the properties are added to the generated users. 
	GenerateTestPropertys.generate_users()
	GenerateTestPropertys.generate()
	GenerateTestPropertys.add_image()
	GenerateTestPropertys.generate_Feature()

If you want to remove the test properties, then you need to delete the database, and set it up again. Not that this will delete the entire database. Use the following steps 

Step 1: go to the project directory and change into the accommodation_app directory. From .../capstone-project-enter-a-group-name/    Type:
	cd accomodation_app

Step 2: delete the database ( remove the following file db.sqlite3 ) 

Step 3 - run makemigrations and migrations. Type: 
python manage.py makemigrations
python manage.py migrate 
